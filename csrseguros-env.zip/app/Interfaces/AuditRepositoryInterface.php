<?php

namespace App\Interfaces;

interface AuditRepositoryInterface extends BaseRepositoryInterface
{
    //
}
