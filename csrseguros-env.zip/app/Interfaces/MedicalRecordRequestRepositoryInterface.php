<?php

namespace App\Interfaces;

interface MedicalRecordRequestRepositoryInterface extends BaseRepositoryInterface
{
    //
}
