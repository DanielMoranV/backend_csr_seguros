<?php

namespace App\Interfaces;

interface ShipmentRepositoryInterface extends BaseRepositoryInterface
{
    //
}
