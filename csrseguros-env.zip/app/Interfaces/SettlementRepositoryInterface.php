<?php

namespace App\Interfaces;

interface SettlementRepositoryInterface extends BaseRepositoryInterface
{
    //
}
